package cn.fnd.service.back;
import cn.fnd.mapper.back.AdminMapper;
import cn.fnd.pojo.Admin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2017/10/20 0020.
 */
@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminMapper adminMapper;
    @Override
    public Admin findAdminByName(String username) {
        return adminMapper.findAdminByName(username);
    }
}
