package cn.fnd.service.back;

import cn.fnd.pojo.ServerOrder;

import java.util.List;

public interface BackServerService {

    public List<ServerOrder> findAllOrder();
}
