package cn.fnd.service.form;

import cn.fnd.mapper.form.FormUserInfoMapper;
import cn.fnd.pojo.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FormUserInfoServiceimpl implements  FormUserInfoService {
    @Autowired
   private FormUserInfoMapper formUserInfoMapper;

    @Override
    public UserInfo findUserInfoByUid(String userId) {
        return formUserInfoMapper.findUserInfoByUId(userId);
    }
}
