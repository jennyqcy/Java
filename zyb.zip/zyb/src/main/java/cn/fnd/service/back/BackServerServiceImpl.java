package cn.fnd.service.back;

import cn.fnd.mapper.back.BackServerMapper;
import cn.fnd.pojo.ServerOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BackServerServiceImpl implements BackServerService{

    @Autowired
    private BackServerMapper backServerMapper;

    public List<ServerOrder> findAllOrder(){
      return   backServerMapper.findAll();
    }
}
