package cn.fnd.service.form;

import cn.fnd.exception.ServiceException;
import cn.fnd.pojo.User;

import java.util.List;

public interface FormUserService {

    List<User> findAll();

    void addUser(User user);

    void processActivate(User user, String email, String validateCode) throws ServiceException;

    User loginUser(String username, String password);

    User findUserByUsername(String username);
}
