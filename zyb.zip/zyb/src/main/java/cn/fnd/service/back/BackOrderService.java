package cn.fnd.service.back;




import cn.fnd.pojo.Order;

import java.util.List;
import java.util.Map;

public interface BackOrderService {

    List<Order> findAll();
    public Double findallMoney();

    public List<Map> findTypeMoney();
}
