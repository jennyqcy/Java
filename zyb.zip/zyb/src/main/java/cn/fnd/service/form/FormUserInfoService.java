package cn.fnd.service.form;

import cn.fnd.pojo.UserInfo;

public interface FormUserInfoService {

    UserInfo findUserInfoByUid(String userId);
}
