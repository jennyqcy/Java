package cn.fnd.service.form;

import cn.fnd.mapper.form.FormServerOrderMapper;
import cn.fnd.pojo.ServerOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by Administrator on 2017/10/21 0021.
 */
@Service
public class FormServerOrderServiceImpl implements FormServerOrderService {
    /**
     *
     */
    @Autowired
    private FormServerOrderMapper formServerOrderMapper;
    @Override
    public List<ServerOrder> findServerOrderByServerId(String serverId) {
        return formServerOrderMapper.findServerOrderByServerId(serverId);
    }

    @Override
    public ServerOrder findSdByServerId(String serverId) {
        return formServerOrderMapper.findSdByServerId(serverId);
    }

    @Override
    public boolean completeServerOrder(String serverId, String updateTime) {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        Date date=new Date();
        long upTime=date.getTime();
        System.out.println("更新时间"+upTime);
        //根据服务的ID查找到开始时间
        ServerOrder serverorder=formServerOrderMapper.findSdByServerId(serverId);
        //获取到开始时间
        String startTime=serverorder.getStartTime();

        try {

            Date sTime= sdf.parse(startTime);


            Long startTimeLong=sTime.getTime();
            System.out.println("开始时间"+startTimeLong);
            //判断开始和更新时间
            if(upTime<startTimeLong){
                return false;
            }else{
                //获取到订单的状态
                int state=2;

                //修改state为2
                formServerOrderMapper.updateServerOrderStatus(state,serverId);
                return true;
            }

        } catch (ParseException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }
}
