package cn.fnd.service.back;


import cn.fnd.pojo.Admin;

/**
 * Created by Administrator on 2017/10/20 0020.
 */
public interface AdminService {
    //通过管理员的姓名查找用户的信息
    Admin findAdminByName(String username);
}
