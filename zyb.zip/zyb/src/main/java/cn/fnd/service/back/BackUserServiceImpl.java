package cn.fnd.service.back;

import cn.fnd.mapper.back.BackUserInfoMapper;
import cn.fnd.mapper.back.BackUserMapper;
import cn.fnd.pojo.User;
import cn.fnd.pojo.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class BackUserServiceImpl implements BackUserService{

    @Autowired
    private BackUserMapper bum;
    @Autowired
    private BackUserInfoMapper buim;

    public List<User> findAll() {
        return bum.findAll();
    }

    public void addUser(User user) {
        //在该层实现其余数据封装
        String userId = UUID.randomUUID().toString();
        //创建时间
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String registTime = sdf.format(date);
        //封装userInfo对象信息
        UserInfo userInfo = user.getUserInfo();
        //设置userInfo的id=user的ID
        userInfo.setUserInfoId(userId);
        //设置userInfo的创建时间 = user 的创建时间
        userInfo.setCreateTime(registTime);
        //封装数据
        user.setUserId(userId);
        user.setRegistTime(registTime);

        buim.addUserInfo(userInfo);
        bum.addUser(user);
    }
    @Override
    public List<User> findUserByUserId(String userId) {
        return bum.findUserByUserId(userId);
    }

    @Override
    public void delteUserById(String[] userIds) {
        bum.deleteUserById(userIds);
    }

    @Override
    public void updateUser(User user) {
        UserInfo userInfo=user.getUserInfo();
        bum.updateUser(user);
        userInfo.setUserInfoId(user.getUserId());
        //更新用户的详细信息
        buim.updateUserInfo(userInfo);
    }
}
