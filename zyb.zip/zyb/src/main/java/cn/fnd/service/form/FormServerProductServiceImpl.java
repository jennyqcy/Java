package cn.fnd.service.form;

import cn.fnd.mapper.form.FormServerProuctMapper;
import cn.fnd.pojo.ServerProduct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

/**
 * Created by Administrator on 2017/10/21 0021.
 */
@Service
public class FormServerProductServiceImpl implements FormServerProductService {
    @Autowired
    private FormServerProuctMapper formServerProuctMapper;

    @Override
    public List<ServerProduct> findAll() {
        return formServerProuctMapper.findAll();
    }

    @Override
    public List<ServerProduct> findServerProductById(String serverId) {
        return formServerProuctMapper.findServerProductById(serverId);
    }

    @Override
    public void addServerProduct(ServerProduct serverProduct) {
        serverProduct.setServerId(UUID.randomUUID().toString());
        formServerProuctMapper.addServerProduct(serverProduct);
    }
}
