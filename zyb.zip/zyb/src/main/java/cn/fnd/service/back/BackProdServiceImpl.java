package cn.fnd.service.back;

import cn.fnd.mapper.back.BackProdMapper;
import cn.fnd.mapper.back.BackProdTypeMapper;
import cn.fnd.pojo.Prod;
import cn.fnd.pojo.ProdType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class BackProdServiceImpl implements BackProdService{
    @Autowired
    private BackProdTypeMapper backProdTypeMapper;
    @Autowired
    private BackProdMapper backProdMapper;
    @Override
    public List<Prod> findAll() {

        return backProdMapper.findAll();
    }

    @Override
    public List<Prod> findProdById(String prodId) {
        return backProdMapper.findProdById(prodId);
    }

    @Override
    public void deleteProds(String[] prodIds) {
        backProdMapper.deleteProds(prodIds);
    }

    @Override
    public void updateProd(Prod prod) {
        backProdMapper.updateProd(prod);
    }

    @Override
    public List<ProdType> findAllTypes() {
        return backProdTypeMapper.findAllTypes();
    }

    @Override
    public void saveProd(Prod prod) {
        String prodId = UUID.randomUUID().toString(); //随机产生的id
        prod.setProdId(prodId);
//        System.out.println(prod.getProdId());
        backProdMapper.saveProd(prod);
    }


}
