package cn.fnd.service.back;

import cn.fnd.pojo.UserInfo;

public interface BackUserInfoService {
    //添加userInfo信息
    void addUserInfo(UserInfo userInfo);
}
