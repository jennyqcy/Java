package cn.fnd.service.back;

import cn.fnd.mapper.back.BackUserInfoMapper;
import cn.fnd.pojo.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class BackUserInfoServiceImpl implements BackUserInfoService {

    @Autowired
    private BackUserInfoMapper buim;


    public void addUserInfo(UserInfo userInfo) {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String createTime = sdf.format(date);

        userInfo.setCreateTime(createTime);
        buim.addUserInfo(userInfo);
    }
}
