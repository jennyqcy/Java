package cn.fnd.service.form;



import cn.fnd.pojo.ServerOrder;

import java.util.List;

/**
 * Created by Administrator on 2017/10/21 0021.
 */
public interface FormServerOrderService {
    //根据服务的ID查找到订单的信息信息
    List<ServerOrder> findServerOrderByServerId(String serverId);
    //根据serverId查找到开始时间
    ServerOrder findSdByServerId(String serverId);
    //根据服务的id和更新时间和数据库中的创建时间做比较
    boolean completeServerOrder(String serverId, String updateTime);
}
