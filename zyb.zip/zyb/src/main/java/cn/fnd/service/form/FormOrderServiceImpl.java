package cn.fnd.service.form;

import cn.fnd.mapper.form.FormOrderItemMapper;
import cn.fnd.mapper.form.FormOrderMapper;
import cn.fnd.pojo.Address;
import cn.fnd.pojo.Order;
import cn.fnd.pojo.OrderItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class FormOrderServiceImpl implements  FormOrderService{


    @Autowired
    private FormOrderItemMapper formOrderItemMapper;
    @Autowired
    private  FormOrderMapper formOrderMapper;


    @Override
    public void addOrderAndOrderItems(Order order) {
     /*order.setCreateTime(new Date().toString());*/
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd  hh:mm:ss");
        String date=sdf.format(new Date());
        order.setCreateTime(date);
        order.setPaystate(0);//设置购买状态
        List<OrderItem> orderItems = order.getOrderItems();
        for(OrderItem orderItem:orderItems){
            orderItem.setOrderId(order.getOrderId());
            formOrderItemMapper.addOrderItems(orderItem);
        }
        formOrderMapper.addOrder(order);

    }

    @Override
    public List<Order> findOrderByUid(String userId) {
        return formOrderMapper.findOrderByUid(userId);
    }

    @Override
    public void updateAddressByOid(String orderId, Address ads) {
         String addressId=ads.getAddressId();
         String address="收货人："+ads.getReceiveName()+" ::电话:"+ads.getTelephone()+"::收货地址："+ads.getPlace();
        formOrderMapper.updateAddressByOid(orderId,addressId,address);

    }

    /*public Order findOrderByOid(String oid) {
        return formOrderMapper.findOrderByOid(oid);
    }*/

    public void updatePayState(String orderId, int payState) {
        formOrderMapper.updatePayState(orderId,payState);
    }
}
