package cn.fnd.service.form;

import cn.fnd.mapper.form.FormAddressMapper;
import cn.fnd.pojo.Address;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class FormAddressServiceImpl implements  FormAddressService{

    @Autowired
    private FormAddressMapper formAddressMapper;
    @Override
    public List<Address> findAddressByUid(String userId) {
        return formAddressMapper.findAddressByUid(userId);
    }

    @Override
    public Address findAddressByAid(String addressId) {
        return formAddressMapper.findAddressByAid(addressId);
    }

    @Override
    public void addAddress(Address address, String userId) {
        address.setAddressId(UUID.randomUUID().toString());
        address.setUserId(userId);
        formAddressMapper.addAddress(address);
    }
}
