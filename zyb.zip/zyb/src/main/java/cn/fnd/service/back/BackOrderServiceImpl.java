package cn.fnd.service.back;


import cn.fnd.mapper.back.BackOrderMapper;
import cn.fnd.pojo.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 查询展示页面所需要的信息 以order_p为主表
 */
@Service
public class BackOrderServiceImpl implements BackOrderService {
    @Autowired
    private BackOrderMapper backOrderMapper;
    @Override
    public List<Order> findAll() {
        return backOrderMapper.findAll();
    }
    public Double findallMoney(){
        return backOrderMapper.allMoney();
    }

    @Override
    public List<Map> findTypeMoney() {
        return backOrderMapper.findTypeMoney();
    }
}
