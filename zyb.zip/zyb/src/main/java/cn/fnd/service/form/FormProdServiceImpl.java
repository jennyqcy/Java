package cn.fnd.service.form;

import cn.fnd.mapper.form.FormProdMapper;
import cn.fnd.pojo.Prod;
import cn.fnd.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 前台商品Service实现类
 */
@Service
public class FormProdServiceImpl implements FormProdService{
    //前台商品Mapper接口

    @Autowired
    private FormProdMapper prodMapper;

    @Override
    public List<Prod> findProdIndex() {
        return prodMapper.findProdIndex();
    }

    @Override
    public List<User> findUserBypId(String prodId) {
        return prodMapper.findUserBypId(prodId);
    }

    @Override
    public Prod findProdBypId(String prodId) {
        return prodMapper.findProdBypId(prodId);
    }

    @Override
    public List<Prod> findShopListByUId(String userId) {
        return prodMapper.findShopListByUId(userId);
    }

    @Override
    public List<Prod> findProdList(Integer page, int i) {
        return prodMapper.findProdList(page,i);
    }

    @Override
    public Integer findCount() {
        return prodMapper.findCount();
    }
}
