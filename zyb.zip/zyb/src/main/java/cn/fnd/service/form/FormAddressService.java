package cn.fnd.service.form;

import cn.fnd.pojo.Address;

import java.util.List;

public interface FormAddressService {

    List<Address> findAddressByUid(String userId);


    Address findAddressByAid(String addressId);


    void addAddress(Address address, String user);
}
