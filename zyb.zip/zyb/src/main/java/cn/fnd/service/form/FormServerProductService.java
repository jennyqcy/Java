package cn.fnd.service.form;



import cn.fnd.pojo.ServerProduct;

import java.util.List;

/**
 * Created by Administrator on 2017/10/21 0021.
 */
public interface FormServerProductService {
    //查询到服务的所有信息并返回
    List<ServerProduct> findAll();
   //通过ID查找服务的详情信息
    List<ServerProduct> findServerProductById(String serverId);
   //新增一个服务信息
    void addServerProduct(ServerProduct serverProduct);
}
