package cn.fnd.service.back;

import cn.fnd.pojo.Prod;
import cn.fnd.pojo.ProdType;

import java.util.List;

public interface BackProdService {
    /**
     * 查询所有商品
     * @return
     */
    List<Prod> findAll();

    /**
     * 根据id查询某个商品
     * @param prodId
     * @return
     */
    List<Prod> findProdById(String prodId);

    /**
     * 根据id批量删除商品
     * @param prodIds
     */
    void deleteProds(String[] prodIds);

    /**
     * 更新商品信息
     * @param prod
     */
    void updateProd(Prod prod);


    /**
     * 查询所有类别
     * @return
     */
    List<ProdType> findAllTypes();

    /**
     * 保存商品信息
     * @param prod
     */
    void saveProd(Prod prod);
}
