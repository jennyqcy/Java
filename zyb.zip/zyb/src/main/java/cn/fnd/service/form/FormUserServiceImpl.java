package cn.fnd.service.form;

import cn.fnd.exception.ServiceException;
import cn.fnd.mapper.form.FormUserMapper;
import cn.fnd.pojo.User;
import cn.fnd.tools.MD5Util;
import cn.fnd.tools.SendEmail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * 前台用户service实现类
 */
@Service
public class FormUserServiceImpl implements FormUserService {
    //前台用户Mapper接口
    @Autowired
    private FormUserMapper userMapper;


    @Override
    public List<User> findAll() {

        System.out.println(userMapper);
        return userMapper.findUserList();
    }

    //注册处理
    @Override
    public void addUser(User user) {
        String username = user.getUsername();
        //获取email
        String email = user.getEmail();
        user.setUserId(UUID.randomUUID().toString());
        user.setPassword(MD5Util.getMD5Hash(user.getPassword(),username));
        user.setGender(1);
        user.setStatus(0);
        user.setValidateCode(MD5Util.encode2hex(username));
        user.setRegistTime(new Date().toString());//获取点击注册按钮事件
        String validateCode = user.getValidateCode();
        //邮件的内容
        StringBuffer stringBuffer = new StringBuffer("点击下面链接进行注册,链接只能使用一次，请尽快注册!");
        stringBuffer.append("</br>");
        stringBuffer.append("<a href=\"http://localhost/activate?action=activate&email=");
        stringBuffer.append(email);
        stringBuffer.append("&validateCode=");
        stringBuffer.append(validateCode);
        stringBuffer.append("\"");
        stringBuffer.append(">");
        stringBuffer.append(validateCode);
        stringBuffer.append("</a>");
        SendEmail.send(email,stringBuffer.toString());
        userMapper.addUser(user);
    }

    @Override
    public void processActivate(User user, String email, String validateCode) throws ServiceException {
        Date currentTime = new Date();
        if(email.equals(user.getEmail())){
            if(validateCode.equals(user.getValidateCode())){
                user.setStatus(1);
                userMapper.update(user);
            }else {
                throw new ServiceException("激活码错误");
            }
        }else {
            throw new ServiceException("邮箱地址错误");
        }

    }

    @Override
    public User loginUser(String username, String password) {

        return userMapper.findUserByUsernameAndPassword(username,password);
    }

    @Override
    public User findUserByUsername(String username) {
        return userMapper.findUserByUsername(username);
    }


}
