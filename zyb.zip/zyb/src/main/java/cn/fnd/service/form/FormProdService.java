package cn.fnd.service.form;

import cn.fnd.pojo.Prod;
import cn.fnd.pojo.User;

import java.util.List;

public interface FormProdService {
    List<Prod> findProdIndex();
    List<User> findUserBypId(String prodId);
    Prod findProdBypId(String prodId);
    List<Prod> findShopListByUId(String userId);
    //查询所有商品的总数
    Integer findCount();
    //分页查询商列表品
    List<Prod> findProdList(Integer page, int i);
}
