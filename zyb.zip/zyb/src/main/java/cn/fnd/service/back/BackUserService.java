package cn.fnd.service.back;

import cn.fnd.pojo.User;

import java.util.List;

public interface BackUserService {
    //后台用户管理 展示所有用户信息
    List<User> findAll();
    //新增用户
    void addUser(User user);
    //根据用户的ID查找用户的详细信息
    List<User> findUserByUserId(String userId);
    //根据用户的id实现批量删除
    void delteUserById(String[] userIds);
    //修改用户的信息
    void updateUser(User user);
}
