package cn.fnd.service.form;

import cn.fnd.pojo.Address;
import cn.fnd.pojo.Order;

import java.util.List;

public interface FormOrderService {

    void addOrderAndOrderItems(Order order);

    List<Order> findOrderByUid(String userId);


    void updateAddressByOid(String orderId, Address address);

    /*Order findOrderByOid(String oid);*/

    void updatePayState(String orderId, int payState);
}
