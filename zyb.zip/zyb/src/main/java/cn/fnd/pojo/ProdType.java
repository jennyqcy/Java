package cn.fnd.pojo;

public class ProdType {
    private int typeId;
    private String name;

    public int getTypeId() {
        return typeId;
    }

    public void setTypeId(int typeId) {
        this.typeId = typeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "ProdType{" +
                "typeId=" + typeId +
                ", name='" + name + '\'' +
                '}';
    }
}
