package cn.fnd.pojo;

/**
 * Created by Administrator on 2017/10/21 0021.
 */
public class ServerProduct {
    private String serverId;  //服务的ID
    private String serverName; //服务的名称
    private double serverPride; //服务的价格
    private User user; //用户的id
    private  String serverTime; //服务的时间
    private String serverAddress;//服务的地址
    private  String demand;//需求

    public String getServerId() {
        return serverId;
    }

    public void setServerId(String serverId) {
        this.serverId = serverId;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public double getServerPride() {
        return serverPride;
    }

    public void setServerPride(double serverPride) {
        this.serverPride = serverPride;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getServerTime() {
        return serverTime;
    }

    public void setServerTime(String serverTime) {
        this.serverTime = serverTime;
    }

    public String getServerAddress() {
        return serverAddress;
    }

    public void setServerAddress(String serverAddress) {
        this.serverAddress = serverAddress;
    }

    public String getDemand() {
        return demand;
    }

    public void setDemand(String demand) {
        this.demand = demand;
    }
}
