package cn.fnd.pojo;

/**
 * Created by Administrator on 2017/10/20 0020.
 */
public class Role {
    private String roleId;
    private String name;
    private String remarks;
    private String createBy;
    private String createTime;
    private String updateBy;
    private String getUpdateTime;

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public String getGetUpdateTime() {
        return getUpdateTime;
    }

    public void setGetUpdateTime(String getUpdateTime) {
        this.getUpdateTime = getUpdateTime;
    }
}
