package cn.fnd.pojo;


import java.sql.Timestamp;

/**
 * Created by Administrator on 2017/10/21 0021.
 */
public class ServerOrder {
    private ServerProduct serverProduct; //服务的ID
    private String orderId; //订单的ID
    private double compete; //完成度
    private Integer state;//状态
    private String createTime;//创建时间
    private String updateTime;//更新时间
    private String startTime;//开始时间

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public ServerProduct getServerProduct() {
        return serverProduct;
    }

    public void setServerProduct(ServerProduct serverProduct) {
        this.serverProduct = serverProduct;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public double getCompete() {
        return compete;
    }

    public void setCompete(double compete) {
        this.compete = compete;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "ServerOrder{" +
                "serverProduct=" + serverProduct +
                ", orderId='" + orderId + '\'' +
                ", compete=" + compete +
                ", state=" + state +
                ", createTime=" + createTime +
                ", updateTime='" + updateTime + '\'' +
                '}';
    }
}

