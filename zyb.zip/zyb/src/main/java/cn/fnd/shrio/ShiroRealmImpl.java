package cn.fnd.shrio;

import cn.fnd.pojo.Admin;
import cn.fnd.service.back.AdminService;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

public class ShiroRealmImpl extends AuthorizingRealm {
    @Autowired
    private AdminService adminService;
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        return null;
    }
    /*为shiro提供真实的用户数据
* 1 通过token获取用户名和密码
* 2 通过用户名和密码获取真实的信息 真实的面膜
* 3 获取数据后 通过info对象返回shiro安全管理器
*
*
*/
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {

//        System.out.println("sdffsdadfs");
        UsernamePasswordToken loginToken=(UsernamePasswordToken) token;
        String username=loginToken.getUsername();
        //通过用户名查询用户信息
        Admin admin=adminService.findAdminByName(username);
        /**
         * 1:principal 真实的用户对象
         * 2credentials 真实的密码
         * 3:realmName  当前realm的名称
         */
        AuthenticationInfo info=new SimpleAuthenticationInfo(admin,admin.getPassword(),this.getName());
        return info;
    }
}
