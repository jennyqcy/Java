package cn.fnd.shrio;

import java.util.Arrays;


import cn.fnd.tools.Md5HashPassword;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authc.credential.SimpleCredentialsMatcher;

public class AuthCredential extends  SimpleCredentialsMatcher{
	//重写加密处理
	@Override
	public boolean doCredentialsMatch(AuthenticationToken token, AuthenticationInfo info) {
		//将用户的明文进行加密出来
		UsernamePasswordToken loginToken=(UsernamePasswordToken) token;
		String username=loginToken.getUsername();
		String password=String.valueOf(loginToken.getPassword());
		//将密码进行加密处理
		String md5Password= Md5HashPassword.getMd5Hash(password,username);
		loginToken.setPassword(md5Password.toCharArray());
		return super.doCredentialsMatch(loginToken, info);
	}
}
