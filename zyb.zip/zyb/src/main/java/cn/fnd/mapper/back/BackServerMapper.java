package cn.fnd.mapper.back;

import cn.fnd.pojo.ServerOrder;

import java.util.List;

public interface BackServerMapper {

    public List<ServerOrder> findAll();
}
