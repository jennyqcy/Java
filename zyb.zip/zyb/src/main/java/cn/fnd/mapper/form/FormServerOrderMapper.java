package cn.fnd.mapper.form;
import cn.fnd.pojo.ServerOrder;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by Administrator on 2017/10/21 0021.
 */
public interface FormServerOrderMapper {
    //根据服务的ID查找到订单的信息信息
    List<ServerOrder> findServerOrderByServerId(String serverId);
    //根据服务的ID查找到开始时间
    ServerOrder findSdByServerId(String serverId);
    //根据服务的ID修改订单的状态
    void updateServerOrderStatus(@Param("state") int state, @Param("serverId") String serverId);
}
