package cn.fnd.mapper.back;

import cn.fnd.pojo.Prod;

import java.util.List;

public interface BackProdMapper {

    List<Prod> findAll();

    void deleteProds(String[] prodIds);

    void updateProd(Prod prod);

    List<Prod> findProdById(String prodId);

    void saveProd(Prod prod);
}
