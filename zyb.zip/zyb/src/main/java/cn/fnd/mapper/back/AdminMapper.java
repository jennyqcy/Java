package cn.fnd.mapper.back;


import cn.fnd.pojo.Admin;

/**
 * Created by Administrator on 2017/10/20 0020.
 */
public interface AdminMapper {
    //根据后台管理员的名字查询管理员的信息
    Admin findAdminByName(String username);
}
