package cn.fnd.mapper.form;

import cn.fnd.pojo.ServerProduct;
import org.springframework.stereotype.Controller;

import java.util.List;

/**
 * Created by Administrator on 2017/10/21 0021.
 */
@Controller
public interface FormServerProuctMapper {
    //查询服务的所有的信息
    List<ServerProduct> findAll();
    //通过服务的id查找到服务的详细信息
    List<ServerProduct> findServerProductById(String serverId);
    //新增一个服务的信息
    void addServerProduct(ServerProduct serverProduct);
}
