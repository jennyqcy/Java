package cn.fnd.mapper.form;

import cn.fnd.pojo.UserInfo;

public interface FormUserInfoMapper {

    UserInfo findUserInfoByUId(String userId);

}
