package cn.fnd.mapper.back;
import cn.fnd.pojo.ProdType;

import java.util.List;

public interface BackProdTypeMapper {
    List<ProdType> findAllTypes();

}
