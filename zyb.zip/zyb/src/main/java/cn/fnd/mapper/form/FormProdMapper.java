package cn.fnd.mapper.form;

import cn.fnd.pojo.Prod;
import cn.fnd.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface FormProdMapper {
    //首页商品展示
    List<Prod> findProdIndex();

    //用商品ID查用户
    List<User> findUserBypId(String prodId);

    //商品ID查询商品
    Prod findProdBypId(String prodId);

    //根据用户id查询订单
    List<Prod> findShopListByUId(String userId);

    //订单添加商品
    void addProdToShop(@Param("userId") String userId, @Param("prodId") String prodId);

    //根据分页查询商品列表
    List<Prod> findProdList(@Param("page") Integer page,@Param("pageSize") int i);
    //查询商品总数
    Integer findCount();
}
