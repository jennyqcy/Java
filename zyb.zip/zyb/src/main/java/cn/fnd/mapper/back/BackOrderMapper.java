package cn.fnd.mapper.back;


import cn.fnd.pojo.Order;

import java.util.List;
import java.util.Map;

public interface BackOrderMapper {
    List<Order> findAll();
    public Double allMoney();

    public List<Map> findTypeMoney();
}
