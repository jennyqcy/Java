package cn.fnd.mapper.form;

import cn.fnd.pojo.Order;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface FormOrderMapper {
    void addOrder(Order order);

    List<Order> findOrderByUid(String userId);

    void updateAddressByOid(@Param("orderId") String orderId, @Param("addressId") String addressId,@Param("address") String address);

    /*Order findOrderByOid(String oid);*/

    void updatePayState(@Param("orderId") String orderId, @Param("payState") int payState);
}
