package cn.fnd.mapper.back;

import cn.fnd.pojo.UserInfo;

public interface BackUserInfoMapper {

    void addUserInfo(UserInfo userInfo);

    void updateUserInfo(UserInfo userInfo);
}
