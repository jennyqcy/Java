package cn.fnd.mapper.form;

import cn.fnd.pojo.OrderItem;

public interface FormOrderItemMapper {
    void addOrderItems(OrderItem orderItem);

}
