package cn.fnd.mapper.form;

import cn.fnd.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface FormUserMapper {

    List<User> findUserList();

    void addUser(User user);

    void update(User user);

    User findUserByUsernameAndPassword(@Param("username") String username, @Param("password") String password);

    User findUserByUsername(String username);



}
