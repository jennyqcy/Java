package cn.fnd.mapper.form;

import cn.fnd.pojo.Address;

import java.util.List;

public interface FormAddressMapper {

    //根据用户名查地址
    List<Address> findAddressByUid(String userId);

    Address findAddressByAid(String addressId);

    void addAddress(Address address);

}
