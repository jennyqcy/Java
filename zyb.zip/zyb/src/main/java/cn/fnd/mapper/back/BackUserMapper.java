package cn.fnd.mapper.back;

import cn.fnd.pojo.User;

import java.util.List;

public interface BackUserMapper {
    //后台用户管理 展示所有用户信息
    List<User> findAll();
    //新增用户操作
    void addUser(User user);
    List<User> findUserByUserId(String userId);

    void deleteUserById(String[] userIds);

    void updateUser(User user);
}
