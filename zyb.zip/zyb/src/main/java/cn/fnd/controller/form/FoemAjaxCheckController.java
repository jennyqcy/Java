package cn.fnd.controller.form;

import cn.fnd.pojo.User;
import cn.fnd.service.form.FormUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
public class FoemAjaxCheckController {

    @Autowired
    private FormUserService userService;

    /**
     * ajax校验
     * @param request
     * @param response
     */
    @RequestMapping(value = "/toAjax",method = RequestMethod.POST,produces = "text/html;charset=utf-8")
    public void toAjax(HttpServletRequest request, HttpServletResponse response, Model model) throws IOException {
        String username = request.getParameter("username");
        User user = userService.findUserByUsername(username);
        response.getWriter().write(user!=null?"用户名已存在":"用户名可以使用");
    }
}
