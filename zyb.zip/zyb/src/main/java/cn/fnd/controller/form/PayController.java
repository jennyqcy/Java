package cn.fnd.controller.form;

import cn.fnd.pojo.Order;
import cn.fnd.service.form.FormOrderService;
import cn.fnd.tools.PaymentUtil;
import cn.fnd.tools.PropUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PayController {

    @Autowired
    private FormOrderService fos;

    //跳转到支付页面
    @RequestMapping("/toPay")
    public String toPay(String orderId, Double money, Model model) {
        model.addAttribute("orderId", orderId);
        model.addAttribute("money", money);
        System.out.println("toPay:" + "orderId:" + orderId + "money" + money);
        return "/form/pay";
    }

    //确定支付
    @RequestMapping("payServer")
    public String payServer(String orderId, Double money, Model model, String pd_FrpId) {
        //1接收订单id
        String oid = orderId;
        //2、准备第三方支付平台需要的参数
        String p0_Cmd = "Buy";//业务类型
        String p1_MerId = PropUtils.getProperty("p1_MerId");
        String p2_Order = oid;//商户的订单号
        //测试时使用
        String p3_Amt = "0.01";//订单金额
        //“正式发布”的时候使用
        /*Order order = fos.findOrderByOid(oid);*/
        /*String p3_Amt = ""+order.getMoney();*/
        String p4_Cur = "CNY";//交易币种
        String p5_Pid = "";//商品名称
        String p6_Pcat = "";//商品分类
        String p7_Pdesc = "";//商品描述
        String p8_Url = PropUtils.getProperty("responseUrl");
        String p9_SAF = "";//送货地址
        String pa_MP = "";//商户的扩展信息
        //支付通道编码 直接获取pd_FrpId
        //String pd_FrpId = pd_FrpId;
        //应答机制
        String pr_NeedResponse = "1";
        //调用工具类生产数据签名
        String hmac = PaymentUtil.buildHmac(p0_Cmd,
                p1_MerId, p2_Order, p3_Amt, p4_Cur, p5_Pid,
                p6_Pcat, p7_Pdesc, p8_Url, p9_SAF, pa_MP,
                pd_FrpId, pr_NeedResponse, PropUtils.getProperty("keyValue"));
        //3、将以上产生保存Model
        model.addAttribute("pd_FrpId", pd_FrpId);
        model.addAttribute("p0_Cmd", p0_Cmd);
        model.addAttribute("p1_MerId", p1_MerId);
        model.addAttribute("p2_Order", p2_Order);
        model.addAttribute("p3_Amt", p3_Amt);
        model.addAttribute("p4_Cur", p4_Cur);
        model.addAttribute("p5_Pid", p5_Pid);
        model.addAttribute("p6_Pcat", p6_Pcat);
        model.addAttribute("p7_Pdesc", p7_Pdesc);
        model.addAttribute("p8_Url", p8_Url);
        model.addAttribute("p9_SAF", p9_SAF);
        model.addAttribute("pa_MP", pa_MP);
        model.addAttribute("pr_NeedResponse", pr_NeedResponse);
        model.addAttribute("hmac", hmac);
        fos.updatePayState(orderId,1);
        return "form/confirm";

    }

    /*@RequestMapping("/CallBack")
    public String callBack(String r6_Order, HttpServletRequest request) {
        System.out.println(r6_Order);
        String orderId = request.getParameter("orderId");
        if(orderId == null){
            orderId = r6_Order;
        }

        return "/";
    }*/


}
