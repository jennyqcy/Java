package cn.fnd.controller.form;

import cn.fnd.pojo.ServerOrder;
import cn.fnd.service.form.FormServerOrderService;
import cn.fnd.service.form.FormServerProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Created by Administrator on 2017/10/21 0021.
 */
@Controller
public class FormServerOrderController {
    @Autowired
    private FormServerOrderService formServerOrderService;

    @RequestMapping("/toOrder")
    public String toOrder(String serverId, Model model) {
        System.out.println(serverId);
        List<ServerOrder> serverOrderList = formServerOrderService.findServerOrderByServerId(serverId);
        for (ServerOrder serverOrder : serverOrderList) {
            System.out.println(serverOrder);
        }
        model.addAttribute("serverOrderList", serverOrderList);
        return "/form/ServerOrder";
    }

    @RequestMapping("/form/completeServerOrder")
    public void completeServerOrder(String serverId, String updateTime, HttpServletResponse response) {
//        System.out.println("11111111111111111111");
        Boolean result = formServerOrderService.completeServerOrder(serverId, updateTime);
        System.out.println(result);
        System.out.println(serverId);
        try {
            response.getWriter().write(result + "");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
