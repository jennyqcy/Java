package cn.fnd.controller.form;
import cn.fnd.pojo.ServerProduct;
import cn.fnd.service.form.FormServerProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/**
 * Created by Administrator on 2017/10/21 0021.
 */
@Controller

public class FormServerController {
@Autowired
private FormServerProductService formServerProductService;
   //跳转到  帮 的页面。并将信息展示出来
   @RequestMapping("/toHelp")
    public String toService(Model model){
     // System.out.print("afsdafsd");
       List<ServerProduct> serverProductList=formServerProductService.findAll();
       model.addAttribute("serverProductList",serverProductList);
       return "/form/serverList";
   }
   //跳转到   帮 的详情页面，并将数据展现出来
   @RequestMapping("/ServerInfo")
   public String ServerInfo(String serverId,Model model){
       List<ServerProduct> serverProductList=formServerProductService.findServerProductById(serverId);
       model.addAttribute("serverProductList",serverProductList);
       return "/form/toViewServerProduct";
   }

    //跳转 求 服务页面
    @RequestMapping("/toPlease")
    public String toHelp(){
        return "/form/serverProductList";
    }
    //实现需要帮助的信息的新增
    @RequestMapping("/addServerProduct")
    public String addServerProduct(ServerProduct serverProduct){
        formServerProductService.addServerProduct(serverProduct);
     return "redirect:/toHelp";
    }

    @RequestMapping("/baidu")
    public String baidu(){

        return "/form/baidu";
    }

}
