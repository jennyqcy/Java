package cn.fnd.controller.back;

import cn.fnd.pojo.Order;
import cn.fnd.service.back.BackOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class BackOrderController {

    @Autowired
   private BackOrderService backOrderService;

    /**
     * 查询订单信息
     * @param model
     * @return
     */
    @RequestMapping("/OrderManage")
    public String toOrderList(Model model){
        List<Order> orderlist = backOrderService.findAll();
        model.addAttribute("orderlist",orderlist);
        return "/back/ProductManage/orderView";
    }
}
