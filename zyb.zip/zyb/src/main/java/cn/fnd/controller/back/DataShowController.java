package cn.fnd.controller.back;

import cn.fnd.pojo.Order;
import cn.fnd.pojo.ServerOrder;
import cn.fnd.pojo.User;
import cn.fnd.service.back.BackOrderService;
import cn.fnd.service.back.BackServerService;
import cn.fnd.service.back.BackUserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("/back")
public class DataShowController {

    @Autowired
    private BackOrderService backOrderService;

    @Autowired
    private BackServerService backServerService;

    @Autowired
    private BackUserService backUserService;

    @RequestMapping("/datashow")
    public String todatashow(Model model) {

        Calendar calendar=Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH,1);
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
        long month = 0;
        try {
            month = simpleDateFormat.parse(simpleDateFormat.format(calendar.getTime())).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        int year=calendar.get(Calendar.YEAR);

//查询商品总订单和活跃订单
       List<Order> orders=backOrderService.findAll();
       double orderMoney=0;
       double n_orderMoney=0;
       double[] year_order_money=new double[12];
       double[] month_order_money=new double[31];
       int orderNum=orders.size();
       int n_orderNum=0;
        for (Order order:orders
             ) {
            try {
                Date date=simpleDateFormat.parse(order.getCreateTime().split(" ")[0]);
                String[] time=simpleDateFormat.format(date).split("-");
                if(date.getTime()>=month){
                    n_orderMoney+=order.getMoney();
                    n_orderNum++;
                    month_order_money[Integer.valueOf(time[2])-1]+=order.getMoney();
                }
                if (time[0].equals(String.valueOf(year))){
                    year_order_money[Integer.valueOf(time[1])-1]+=order.getMoney();
                }
            } catch (ParseException e) {
                e.printStackTrace();
                continue;
            } catch (NumberFormatException e) {
                e.printStackTrace();
                continue;
            }
            orderMoney+=order.getMoney();
        }
//查询服务总订单和本月新增订单
       List<ServerOrder> serverOrders=backServerService.findAllOrder();
       double serverMoney=0;
       double n_serverMoney=0;
       double[] year_server_money=new double[12];
       double[] month_server_money=new double[31];
       int serverNum=serverOrders.size();
       int n_serverNum=0;
        for (ServerOrder serverOrder:serverOrders
             ) {
            try {
                Date date=simpleDateFormat.parse(serverOrder.getCreateTime().split(" ")[0]);
                String[] time=simpleDateFormat.format(date).split("-");
                if(date.getTime()>=month){
                    n_serverMoney+=serverOrder.getServerProduct().getServerPride();
                    n_serverNum++;
                    month_server_money[Integer.valueOf(time[2])-1]+=serverOrder.getServerProduct().getServerPride();
                }
                if (time[0].equals(String.valueOf(year))){
                   year_server_money[Integer.valueOf(time[1])-1]+=serverOrder.getServerProduct().getServerPride();
                }
                serverMoney+=serverOrder.getServerProduct().getServerPride();
            } catch (ParseException e) {
                e.printStackTrace();
                continue;
            } catch (NumberFormatException e) {
                e.printStackTrace();
                continue;
            }
        }

        DecimalFormat df=new DecimalFormat("#.00");
        double pallMoney=(n_orderMoney+n_serverMoney)/(orderMoney+serverMoney) *100;
        double pallNum=(n_orderNum+n_serverNum)*1.0/(orderNum+serverNum)*100;

//查询活跃用户
        List<User> users=backUserService.findAll();
        int user_num=users.size();
        int n_user_num=0;
        for (User user :
                users) {

            try {
                if(simpleDateFormat.parse(user.getLoginTime()).getTime()>month){
                    n_user_num++;
                }
            } catch (ParseException e) {
//                System.out.println("时间转换失败");
                continue;
            } catch (NullPointerException e){
//                System.out.println("用户没有登录时间");
                continue;
            }
        }
        double puser_num=1.0*n_user_num/user_num*100;

        model.addAttribute("allMoney",df.format(pallMoney));
        model.addAttribute("allOrder",df.format(pallNum));
        model.addAttribute("n_allMoney",n_orderMoney+n_serverMoney);
        model.addAttribute("n_allOrder",n_orderNum+n_serverNum);
        model.addAttribute("puser_num",df.format(puser_num));
        model.addAttribute("n_user_num",n_user_num);
        model.addAttribute("month",calendar.get(Calendar.MONTH)+1);
        model.addAttribute("year_order_money", Arrays.toString(year_order_money));
        model.addAttribute("year_server_money",Arrays.toString(year_server_money));
        model.addAttribute("month_order_money",Arrays.toString(month_order_money));
        model.addAttribute("month_server_money",Arrays.toString(month_server_money));
        model.addAttribute("n_orderMoney",n_orderMoney);
        model.addAttribute("n_serverMoney",n_serverMoney);
        return "back/datashow/datashow";
    }

    @RequestMapping("/proddata")
    public String prodshow(Model model){
        Calendar calendar=Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH,1);
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
        long month = 0;
        try {
            month = simpleDateFormat.parse(simpleDateFormat.format(calendar.getTime())).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        int year=calendar.get(Calendar.YEAR);

//查询商品总订单和活跃订单
        List<Order> orders=backOrderService.findAll();
        double orderMoney=0;
        double n_orderMoney=0;
        double[] year_order_money=new double[12];
        double[] year_order_num=new double[12];
        int orderNum=orders.size();
        int n_orderNum=0;
        for (Order order:orders
                ) {
            try {
                Date date=simpleDateFormat.parse(order.getCreateTime().split(" ")[0]);
                String[] time=simpleDateFormat.format(date).split("-");
                if(date.getTime()>=month){
                    n_orderMoney+=order.getMoney();
                    n_orderNum++;
                }
                if (time[0].equals(String.valueOf(year))){
                    year_order_money[Integer.valueOf(time[1])-1]+=order.getMoney();
                    year_order_num[Integer.valueOf(time[1])-1]++;
                }
            } catch (ParseException e) {
                e.printStackTrace();
                continue;
            } catch (NumberFormatException e) {
                e.printStackTrace();
                continue;
            }
            orderMoney+=order.getMoney();
        }


        DecimalFormat df=new DecimalFormat("#.00");

        double sumMoney=0;
        for(int i=0;i<year_order_money.length;i++){
            sumMoney+=year_order_money[i];
        }
        int sumNum=0;
        for(int i=0;i<year_order_num.length;i++){
           sumNum+=year_order_num[i];
        }

        List<Map> all=backOrderService.findTypeMoney();
        String data=null;
        try {
        data=new ObjectMapper().writeValueAsString(all);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        List<String> name=new ArrayList<String>();
        for (Map<String,String> map:
             all) {
            name.add("'"+map.get("name")+"'");
        }

        model.addAttribute("sumMoney",sumMoney);
        model.addAttribute("sumNum",sumNum);
        model.addAttribute("month",calendar.get(Calendar.MONTH)+1);
        model.addAttribute("year_order_money", Arrays.toString(year_order_money));
        model.addAttribute("year_order_num",Arrays.toString(year_order_num));

        model.addAttribute("data",data);
        model.addAttribute("name",name);
        System.out.println(name);
        return "back/datashow/proddata";
    }
}
