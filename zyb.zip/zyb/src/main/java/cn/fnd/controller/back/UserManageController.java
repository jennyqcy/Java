package cn.fnd.controller.back;

import cn.fnd.pojo.User;
import cn.fnd.pojo.UserInfo;
import cn.fnd.service.back.BackUserInfoService;
import cn.fnd.service.back.BackUserService;
import cn.fnd.tools.POIUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/back")
public class UserManageController {
    @Autowired
    private BackUserService bus;

    //跳转到用户管理页面
    @RequestMapping("/toUserList")
    public String toUserManage(Model model)  {
        List<User> userList=bus.findAll();
        try {
            POIUtil.POIprint(userList);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        model.addAttribute("userList",userList);
        return "/back/UserManage/UserList";
    }

    //跳转到用户新增页面
    @RequestMapping("/toInsert")
    public String toInsert(Model model){
//        String userId = UUID.randomUUID().toString();
//        System.out.println("toInsert---"+userId);
//        model.addAttribute("userId",userId);
        return "/back/UserManage/UserCreate";
    }

    //用户新增操作 插入一个完整的用户信息
    @RequestMapping("/addUser")
    public String addUser(User user){
        //因为隐藏域中穿过来的只有一个userId
//        userInfo.setUserInfoId(user.getUserId());
        System.out.println(user);
        System.out.println("Controller层");
        //在service层做出业务逻辑处理
        bus.addUser(user);
        return "redirect:/back/toUserList";
    }
    //查看用户的详细信息
    @RequestMapping("/toLook")
    public String toLook(String userId,Model model){
        List<User> userList=bus.findUserByUserId(userId);
        model.addAttribute("userList",userList);
        return "/back/UserManage/toViewUserInfo";
    }
    //删除一条用户信息
    @RequestMapping("/toDelete")
    public String toDelete(@RequestParam("userId") String[] userIds){
        bus.delteUserById(userIds);
        return "redirect:/back/toUserList";
    }
    //跳转到用户信息修改页面
    @RequestMapping("/toUpdate")
    public String toUpdate(String userId,Model model){
        //根据用户的ID将用户的详细信息查询出来

       List<User>  userList=bus.findUserByUserId(userId);
        System.out.println(userId);
        model.addAttribute("userList",userList);
        return "/back/UserManage/toViewUser";
    }
    //实现用户信息的修改
    @RequestMapping("/updateUser")
    public String updateUser(User user){
        bus.updateUser(user);
        return "redirect:/back/toUserList";
    }

    //下载用户信息poi报表
    @RequestMapping("/downUser")
    public String downUser(){
        //报表
        List<User> userList=bus.findAll();
        return "";
    }

}
