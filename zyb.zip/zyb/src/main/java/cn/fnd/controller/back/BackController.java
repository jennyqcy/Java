package cn.fnd.controller.back;

import cn.fnd.pojo.Admin;
import cn.fnd.pojo.User;
import cn.fnd.service.back.AdminService;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;

import org.apache.shiro.SecurityUtils;

import javax.servlet.http.HttpSession;

/**
 * 后台管理员的登陆
 */
@Controller
@RequestMapping("/back")
public class BackController {

    @Autowired
    private AdminService adminService;
    //跳转到后台的首页
    @RequestMapping("/index")
    public String backIndex(){
        return "/back/index";
    }


    /**
     * 跳转到后台的登录页面
     * @return
     */
    @RequestMapping("/toLogin")
    public String backLogin(){
        return "/back/login";

    }

    /**
     * 后台登录的具体实现代码
     * @param username 用户名
     * @param password  密码
     * @param model   模型类
     * @return  返回页面
     */
    @RequestMapping("/login")
    public String Login(String username, String password, Model model,HttpSession httpSession){
        if(StringUtils.isEmpty(username) || StringUtils.isEmpty(password)){
            model.addAttribute("ErrrInfo","用户名或密码不能为空");
            return "/back/login";
        }
        //创建令牌
        UsernamePasswordToken token=new UsernamePasswordToken(username,password);
        //创建入口类
        Subject subject= SecurityUtils.getSubject();
        try {
            subject.login(token);
            Admin admin = (Admin) subject.getPrincipal();
            httpSession.setAttribute("adminSession",admin);
            return "/back/index";
        }catch (AuthenticationException e) {
            //将报错信息打印出来
            e.printStackTrace();
            return "/back/login";

        }
    }

    //跳转到安全退出页面
    @RequestMapping("/toLogout")
    public String toLogout(HttpSession httpSession){
        try {
            Subject subject=SecurityUtils.getSubject();
            if(subject.isAuthenticated()){
                subject.logout();
            }
        }
        catch (Exception e){
            return "redirect:/back/toLogin";
        }

        return "redirect:/back/index";

    }
}
