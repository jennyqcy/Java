package cn.fnd.controller.form;

import cn.fnd.controller.BaseController;
import cn.fnd.exception.MsgException;
import cn.fnd.exception.ServiceException;
import cn.fnd.pojo.*;
import cn.fnd.service.form.*;
import cn.fnd.tools.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Controller
public class FormController extends BaseController {
    @Autowired
    private FormProdService prodService;
    @Autowired
    private FormUserService userService;
    @Autowired
    private FormUserInfoService formUserInfoService;
    @Autowired
    private FormAddressService formAddressService;
    @Autowired
    private FormOrderService formOrderService;


    //登录到前台首页
    @RequestMapping("/")
    public String toIndex(Model model) {
        List<Prod> prodIndexList = prodService.findProdIndex();
        model.addAttribute("prodIndexList", prodIndexList);
        return "/form/index";
    }

    //跳转到登录页
    @RequestMapping("/toLogin")
    public String toLogin() {

        return "/form/login";
    }

    @RequestMapping("/login")
    public String login(String username, String password, Model model, HttpSession session) throws MsgException {
        if (username != null && password != null) {
            String md5Password = MD5Util.getMD5Hash(password, username);
            User user = userService.loginUser(username, md5Password);
            if (user == null) {
                System.out.println("-------------------------------------------");
                model.addAttribute("msg", "用户名或密码错误!");
                return "/form/login";
            } else {
                String userId = user.getUserId();
                UserInfo userInfoByUid = formUserInfoService.findUserInfoByUid(userId);
                user.setUserInfo(userInfoByUid);
                session.setAttribute("user", user);
                return "redirect:/";
            }
        } else {
            model.addAttribute("msg", "用户名或密码不能为空");
            return "/form/login";
        }
    }

    //跳转到注册页
    @RequestMapping("/toRegist")
    public String toRegist() {

        return "/form/regist";
    }

    /**
     * 注册
     * 利用AJAX验证用户名是否存在
     * 发送验证邮件
     *
     * @param user
     * @param model
     * @param session
     * @return
     */
    @RequestMapping("/regist")
    public String regist(User user, Model model, HttpSession session) {
        try {
            user.checkData();
        } catch (MsgException e) {
            e.printStackTrace();
            model.addAttribute("msg", e.getMessage());
            return "/form/regist";
        }
        User user1 = userService.findUserByUsername(user.getUsername());
        if (user1 != null) {
            model.addAttribute("msg", "用户名已存在");
            return "/form/regist";
        }
        session.setAttribute("user", user);
        System.out.println(user.getEmail());
        userService.addUser(user);
        System.out.println("发送成功");
        return "redirect:http://mail.163.com/";
    }

    /**
     * @param email        接收到激活码的邮箱
     * @param validateCode 激活码
     * @return
     */
    @RequestMapping(value = "/activate", method = {RequestMethod.GET, RequestMethod.POST})
    public String activate(String email, String validateCode, HttpSession session) throws ServiceException {

        User user = (User) session.getAttribute("user");

        userService.processActivate(user, email, validateCode);

        return "/form/login";
    }

    @RequestMapping("/toLogout")
    public String toLogout(HttpSession httpSession) {
        //将user对象从session域中删除
        httpSession.removeAttribute("user");
        return "/form/index";
    }

    //跳转到商品列表页
    @RequestMapping("/toProdList")
    public String toProdList(Model model, Integer page) {
        Integer rows = prodService.findCount();
        if (page == null) {
            page = 1;
        }
        List<Integer> pages = new ArrayList<Integer>();
        for (int i = 0; i < rows; i += 9) {
            pages.add(i);
        }
        model.addAttribute("pages", pages);
        Integer nowPage = page;
        model.addAttribute("nowPage", nowPage);
        page = (page - 1) * 9;
        List<Prod> list = prodService.findProdList(page, 9);
        model.addAttribute("list", list);

        return "/form/prodList";
    }

    //跳转到商品详情页
    @RequestMapping("/toProdInfo")
    public String toProdInfo(Model model, String prodId) {
        List<User> userBypId = prodService.findUserBypId(prodId);
        Prod prodBypId = prodService.findProdBypId(prodId);
        model.addAttribute("prodBypId", prodBypId);
        model.addAttribute("userBypId", userBypId.get(0));
        //要使用商品ID查询商品跳转到详情页
        return "/form/prodInfo";
    }

    //跳转到购物车页面
    @RequestMapping("/toShopList")
    public String toShopList(HttpSession session, Model model, @RequestParam(required = false) String prodId, @RequestParam(required = false) Integer buyNum) {
        System.out.print(prodId);
        if (prodId == null) {
            return "/form/shopList";
        }
        //得到存入session中的商品
        Map<Prod, Integer> shopList = (Map<Prod, Integer>) session.getAttribute("shopList");
        //根据商品id查商品
        Prod prod = prodService.findProdBypId(prodId);

        Integer prodNum = prod.getProdNum();

        if (shopList.containsKey(prod)) {//判断商品的map中是否有一样的商品
            if (buyNum == -1) {//如果商品数量为-1就删除商品

                shopList.remove(prod);
                return "/form/shopList";
            }
            if (shopList.get(prod) + buyNum > prodNum) {//如果商品数量喝购买数量超过库存，就默认购买库存数量
                shopList.put(prod, prodNum);
                model.addAttribute("msg", "亲：这是最大库存^o^");
                return "/form/shopList";
            }

            shopList.put(prod, shopList.get(prod) + buyNum);
            return "/form/shopList";
        }
        if (buyNum > prodNum) {
            shopList.put(prod, prodNum);
            model.addAttribute("msg", "亲：这是最大库存^o^");
            return "/form/shopList";
        }

        shopList.put(prod, buyNum);
        return "/form/shopList";
    }

    //添加订单
    @RequestMapping("/saveOrder")
    public String saveOrder(HttpSession session, Double sum) {
        //查看用户是否登录，如果未登录就跳转到登录页面
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/toLogin";
        }
        //添加订单和订单项
        String userId = user.getUserId();
        List<Address> addressByUid = formAddressService.findAddressByUid(userId);
        Map<Prod, Integer> shopList = (Map<Prod, Integer>) session.getAttribute("shopList");
        List<OrderItem> orderItems = new ArrayList<OrderItem>();
        for (Map.Entry<Prod, Integer> shop : shopList.entrySet()) {
            OrderItem orderItem = new OrderItem();
            orderItem.setProdId(shop.getKey().getProdId());
            orderItem.setBuyNum(shop.getValue());
            orderItems.add(orderItem);
        }
        Order order = new Order();
        for (Address ads : addressByUid) {
            if ((ads.getIsDefault() == null ? 0 : ads.getIsDefault()) == 1) {
                order.setAddressId(ads.getAddressId());
                String address = "收货人：" + ads.getReceiveName() + " ::电话:" + ads.getTelephone() + "::收货地址：" + ads.getPlace()
                        + "," + ads.getAddress();
                order.setAddress(address);
            }
        }


        order.setOrderId(UUID.randomUUID().toString());
        order.setOrderItems(orderItems);

        order.setBuyId(userId);
        order.setMoney(sum);
        formOrderService.addOrderAndOrderItems(order);


        //清空购物车
        shopList.clear();


        return "redirect:/toBill";
    }

    //跳转到订单页面
    @RequestMapping("/toBill")
    public String toBill(Model model, HttpSession session) {
        User user = (User) session.getAttribute("user");
        if(user == null){
            return "/form/login";
        }
        String userId = user.getUserId();
        //根据用户id查询该用户的所以地址
        List<Address> addressByUid = formAddressService.findAddressByUid(userId);
        model.addAttribute("addressByUid", addressByUid);
        //根据用户id得到所有订单
        List<Order> orderList = formOrderService.findOrderByUid(userId);
        model.addAttribute("orderList", orderList);

        return "/form/bill";
    }


    //订单修改地址
    @RequestMapping("/updateaddress")
    public String updateAddress(String orderId, String addressId) {
        //根据地址id查询地址
        Address address = formAddressService.findAddressByAid(addressId);
        //修改订单的地址和地址id
        formOrderService.updateAddressByOid(orderId, address);

        return "redirect:/toBill";
    }

    @RequestMapping("/setAddress")
    public String setAddress() {
        return "/form/setAddress";
    }

    @RequestMapping("/saveAddress")
    public String saveAddress(Address address, HttpSession session) {
        formAddressService.addAddress(address, ((User) session.getAttribute("user")).getUserId());


        return "redirect:/toBill";
    }


}
