package cn.fnd.controller.back;

import cn.fnd.pojo.Prod;
import cn.fnd.pojo.ProdType;
import cn.fnd.service.back.BackProdService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/back")
public class BackProdController {


    @Autowired
    private BackProdService backProdService;

    /**
     * 展示商品信息
     * @param model
     * @return
     */
    @RequestMapping("/productManage")
    public String deleteProd(Model model){
        List<Prod> prodlist = backProdService.findAll();
        model.addAttribute("prodlist",prodlist);
        return "/back/ProductManage/productList";
    }

    /**
     * 根据prodId删除某个商品
     * @param prodIds
     * @return
     */
    @RequestMapping("/delete")
    public  String deleteProd(@RequestParam("prodId") String[] prodIds){
        backProdService.deleteProds(prodIds);

        return "redirect:/back/productManage";
    }




    /**
     * 转到更新页面
     * @param prodId
     * @param model
     * @return
     */
    @RequestMapping("/Update")
    public  String updateProd(String prodId,Model model){
        List<Prod> prodList = backProdService.findProdById(prodId);
        model.addAttribute("prodList",prodList);
        return "/back/ProductManage/toViewProduct";
    }

    /**
     * 根据传进来的用户更新
     * @param prod
     * @return
     */
    @RequestMapping("/updateProduct")
    public String toUpdateProd(Prod prod){
        backProdService.updateProd(prod);
        return "redirect:/back/productManage";
    }


    /**
     * 展示商品
     * @param prodId
     * @param model
     * @return
     */
    @RequestMapping("/toview")
    public String showProd(String prodId,Model model){
        List<Prod> prodList = backProdService.findProdById(prodId);
        model.addAttribute("prodList",prodList);
        return "/back/ProductManage/toViewProdInfo";
    }
/*

    */
/**
     * 转到添加商品页面
     * @param model
     * @return
     *//*

    @RequestMapping("/toAdd")
    public String toAddProd(Model model){

        List<ProdType> prodtypelist = backProdService.findAllTypes();
        model.addAttribute("prodtypelist",prodtypelist);
        return "/back/ProductManage/productAdd";
    }

    */
/**
     * 把传进来的prod添加商品信息
     * @param prod
     * @return
     *//*

    @RequestMapping("/add")
    public String addProd(Prod prod){
        backProdService.saveProd(prod);
        return "redirect:/productManage";
    }
*/


}
