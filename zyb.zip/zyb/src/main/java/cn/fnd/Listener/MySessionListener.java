package cn.fnd.Listener;


import cn.fnd.pojo.Prod;
import org.springframework.stereotype.Component;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import java.util.HashMap;

@WebListener
@Component
public class MySessionListener implements HttpSessionListener{
    @Override
    public void sessionCreated(HttpSessionEvent httpSessionEvent) {
        HttpSession session = httpSessionEvent.getSession();
        long count =(Long)session.getServletContext().getAttribute("count");
        session.getServletContext().setAttribute("count",count+1);
        session.setAttribute("shopList",new HashMap<Prod,Integer>());

    }

    @Override
    public void sessionDestroyed(HttpSessionEvent httpSessionEvent) {

    }
}
