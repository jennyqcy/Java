package cn.fnd.Listener;

import org.springframework.stereotype.Component;

import javax.servlet.ServletContextEvent;
import javax.servlet.annotation.WebListener;

@WebListener
@Component
public class ServletContextListener implements javax.servlet.ServletContextListener{
    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        long count=0;
        servletContextEvent.getServletContext().setAttribute("count",count);
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {

    }
}
