package cn.fnd.tools;

import org.apache.shiro.crypto.hash.Md5Hash;

public class Md5HashPassword {

    public static String getMd5Hash(String password,String username){
        Md5Hash md5=new Md5Hash(password,username,3);
        return md5.toString();
    }

}
