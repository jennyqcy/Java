package cn.fnd.tools;

import org.apache.shiro.crypto.hash.Md5Hash;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Util {
    /**
     * 将源字符串使用MD5加密为字节数组
     * @param source
     * @return
     */
    public static byte[] encode2bytes(String source){
       byte[] result = null;

        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.reset();
            md.update(source.getBytes("UTF-8"));
            result = md.digest();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 将元字符串使用MD5加密为32位16进制数
     * @param source
     * @return
     */
    public static String encode2hex(String source){
        byte[] data = encode2bytes(source);

        StringBuffer hexString = new StringBuffer();
        for(int i = 0; i<data.length;i++){
            String hex = Integer.toHexString(0xff & data[i]);
            if(hex.length() == 1){
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    /**
     * 验证字符串是否匹配
     * @param unknown 待验证字符串
     * @param okHex 加密后的字符串
     * @return 匹配为true不匹配为false
     */
    public static boolean validate(String unknown, String okHex){
        return okHex.equals(encode2hex(unknown));
    }

    //利用MD5加密密码
    public static String getMD5Hash(String username, String password){

        Md5Hash md5Hash = new Md5Hash(password,username,3);

        return md5Hash.toString();
    }
}
