package cn.fnd.tools;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.*;

public class POIUtil {
    public  static void  POIprint(List list) throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {


        List<String> properties =new ArrayList<String>();
        Class clz = list.get(0).getClass();

        Field[] fields = clz.getDeclaredFields();
        for (Field field : fields) {
            properties.add(field.getName());
        }
        for (String p : properties) {
            System.out.println(p);
        }

        Workbook wb = new XSSFWorkbook();

        Map<String, CellStyle> styles = createStyles(wb);
        int len = list.size()/10;
        if(list.size()%10!=0){
            len = len+1;
        }
        int count = 0;
        for (int i = 0; i < len; i++) {
            //create a sheet for each month
            Sheet sheet = wb.createSheet("" + i);

            //turn off gridlines
            sheet.setDisplayGridlines(false);
            sheet.setPrintGridlines(false);
            sheet.setFitToPage(true);
            sheet.setHorizontallyCenter(true);
            PrintSetup printSetup = sheet.getPrintSetup();
            printSetup.setLandscape(true);

            //the following three statements are required only for HSSF
            sheet.setAutobreaks(true);
            printSetup.setFitHeight((short) 1);
            printSetup.setFitWidth((short) 1);

            //the header row: centered text in 48pt font
            Row headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints(80);
            Cell titleCell = headerRow.createCell(0);
            titleCell.setCellValue(clz.getSimpleName());
            titleCell.setCellStyle(styles.get("title"));
            //跨连接从$A$1:$N$1 A1 到N1
            sheet.addMergedRegion(CellRangeAddress.valueOf("$A$1:$B$1"));

            //header with month titles
            Row colRow = sheet.createRow(1);
            for (int j = 0; j < properties.size(); j++) {
                //set column widths, the width is measured in units of 1/256th of a character width
                sheet.setColumnWidth(j, 10 * 256); //the column is 5 characters wide
                //sheet.setColumnWidth(j*2 + 1, 13*256); //the column is 13 characters wide
                //sheet.addMergedRegion(new CellRangeAddress(1, 1, i*2, i*2+1));
                Cell properityCell = colRow.createCell(j);
                properityCell.setCellStyle(styles.get("property"));
                properityCell.setCellValue(properties.get(j));
            }

            int rownum = 2;
            for (int j = 0; j < 10; j++) {


                if (count < list.size()) {
                    Object data = list.get(count++);
                    Row row = sheet.createRow(rownum++);
                    row.setHeightInPoints(100);
                    //开始写入行

                    for (int k = 0; k < properties.size(); k++) {
                        Cell nameCell_1 = row.createCell(k);
                        String name = properties.get(k);
                        name = "get" + name.substring(0, 1).toUpperCase() + name.substring(1, name.length());
                        Method m = clz.getMethod(name);
                        Object o =  m.invoke(data);
                        if(o!=null) {
                            if(o instanceof String){
                                nameCell_1.setCellValue(o.toString());
                            }else if(o instanceof Date){
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                                nameCell_1.setCellValue(sdf.format((Date)o));
                            }else if(o instanceof Integer ||o instanceof Double){
                                System.out.println(o.toString());
                                nameCell_1.setCellValue(o.toString());
                            } else{
                                nameCell_1.setCellValue("");
                            }

                        }else{
                            nameCell_1.setCellValue("null");
                        }

                    }
                } else {
                    // Write the output to a file
                    File file = new POIUtil().crrateFile();
                    String fileName = file.getPath();
                    //if(wb instanceof XSSFWorkbook) fileName += "x";
                    FileOutputStream out = new FileOutputStream(fileName);
                    wb.write(out);
                    out.close();
                    wb.close();
                    return;


                }
            }


        }
        File file = new POIUtil().crrateFile();
        String fileName  = file.getPath();
        //if(wb instanceof XSSFWorkbook) fileName += "x";
        FileOutputStream out = new FileOutputStream(fileName);
        wb.write(out);
        out.close();
        wb.close();



    }

    /*public static void writeData(Object o,Row row){
        if(o!=null) {
            if(o instanceof String){
                Cell nameCell_1 = row.createCell();
                nameCell_1.setCellValue(o.toString());
            }if(list instanceof List){

            }
            else{
                nameCell_1.setCellValue("null2");
            }

        }else{
            nameCell_1.setCellValue("null");
        }
    }*/
    public File crrateFile() throws IOException {
        File file = new File("data.xlsx");
        System.out.println(file.getPath());
        if(!file.exists()){
            file.createNewFile();
            return file;
        }
        FileWriter fw = new FileWriter(file);
        fw.write("");
        fw.close();
        return file;
    }

    /**
     * cell styles used for formatting calendar sheets
     */
    private static Map<String, CellStyle> createStyles(Workbook wb){
        Map<String, CellStyle> styles = new HashMap<String, CellStyle>();

        short borderColor = IndexedColors.GREY_50_PERCENT.getIndex();

        CellStyle style;
        Font titleFont = wb.createFont();
        titleFont.setFontHeightInPoints((short)48);
        titleFont.setColor(IndexedColors.DARK_BLUE.getIndex());
        style = wb.createCellStyle();
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setFont(titleFont);
        styles.put("title", style);

        Font monthFont = wb.createFont();
        monthFont.setFontHeightInPoints((short)12);
        monthFont.setColor(IndexedColors.WHITE.getIndex());
        monthFont.setBold(true);
        style = wb.createCellStyle();
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setFont(monthFont);
        styles.put("property", style);

        Font dayFont = wb.createFont();
        dayFont.setFontHeightInPoints((short)14);
        dayFont.setBold(true);
        style = wb.createCellStyle();
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderLeft(BorderStyle.THIN);
        style.setLeftBorderColor(borderColor);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBottomBorderColor(borderColor);
        style.setFont(dayFont);
        styles.put("weekend_left", style);

        style = wb.createCellStyle();
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderRight(BorderStyle.THIN);
        style.setRightBorderColor(borderColor);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBottomBorderColor(borderColor);
        styles.put("weekend_right", style);

        style = wb.createCellStyle();
        style.setAlignment(HorizontalAlignment.LEFT);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setBorderLeft(BorderStyle.THIN);
        style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setLeftBorderColor(borderColor);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBottomBorderColor(borderColor);
        style.setFont(dayFont);
        styles.put("workday_left", style);

        style = wb.createCellStyle();
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderRight(BorderStyle.THIN);
        style.setRightBorderColor(borderColor);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBottomBorderColor(borderColor);
        styles.put("workday_right", style);

        style = wb.createCellStyle();
        style.setBorderLeft(BorderStyle.THIN);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBottomBorderColor(borderColor);
        styles.put("grey_left", style);

        style = wb.createCellStyle();
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderRight(BorderStyle.THIN);
        style.setRightBorderColor(borderColor);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBottomBorderColor(borderColor);
        styles.put("grey_right", style);

        return styles;
    }
}
